module.exports = {
    PORT : 3001,
    secretekey : 'fyewfuywfhijwe',
    db : {
        host : 'localhost',
        user :'postgres' ,
        password :'123456',
        database : 'articles'
    },
    mongo : {
        uri : "mongodb+srv://pavani:123456pP@cluster0.a4a7z.mongodb.net/em?retryWrites=true&w=majority",
    }
}