const mongoose = require('mongoose')

const postSchema = new mongoose.Schema({
    blogid : {
        type : mongoose.Schema.Types.ObjectId,
        required : true,
        trime : true
    },
    postedby : {
        type : String,
        required : true,
        trime : true
    },
    comments : {
        type : String,
        required : true,
        trime : true
    }
})

const Post = mongoose.model('Post',postSchema)

module.exports = Post;