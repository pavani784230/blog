const mongoose = require('mongoose')

const blogschema = new mongoose.Schema({
    title :{
        type : String,
        required : true,
        trime :true
    },
    description:{
        type : String,
        required : true,
        trime :true
    },
    categoryid:{
        type : mongoose.Schema.Types.ObjectId,
        ref: 'Categories',
        required : true,
        trime :true
    },
    status:{
        type : String,
        required : true,
        trime :true
    },
    createdby:{
        type : mongoose.Schema.Types.ObjectId,
        ref:'User',
        required : true,
        trime :true
    },
    createdat:{
        type : Date,
        required : false,
        trime :true
    },
    image :{
        type : String,
        required : false,
        trime :true
    },
}, {
    timestamps : true

});

const Blog = mongoose.model('Blog', blogschema);

module.exports = Blog;