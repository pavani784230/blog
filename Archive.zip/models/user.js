const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
    name : {
        type : String,
        required: true,
        trim: true
    },
    
    user_name : {
       type : String,
       required : true,
       trime : true
    },

    password : {
        type : String,
        required : true,
        trime : true
    },
    email : {
        type : String,
        required : true,
        trime : true
    },

    role : {
        type : String,
        default : "user",
        required : true,
        trime : true
    },
    status : {
        type : String,
        required : true,
        trime : true
    },
    createdat : {
        type : Date,
        required : false,
        trime : true
    },

    newpassord : {
        type : String,
        required : false,
        trime : true
    },
    image : {
        type : String,
        required : false,
        trime : true
    },
}, {
    timestamps: true
});

const User = mongoose.model('User', userSchema);

module.exports = User;