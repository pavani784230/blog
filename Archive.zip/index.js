const express = require('express')
const app = express();
const config = require('./config')
// const db = require('./db')
// const roots = require('./roots')
const multer  = require('multer')
const upload = multer({ dest: 'uploads/' })
const mongo = require('./mongo');
const routes = require('./routes')

app.use(express.json())
// app.use('/',roots)
app.use('/',routes)

app.listen(config.PORT,(err => {
    if (err) throw new error (err)
    console.log("currently port is running on:",config.PORT)
}))