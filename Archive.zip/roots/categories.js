const routes = require ('express').Router()
const {categories,list, update, deleteCat, activelist} = require('../controller/categories')
const{categoriesvalidations,updatevalidations,deletevalidations} = require('../validations/categoriesvalidations')
const {verify} = require('../validations/auth')

routes.post('/categories',verify, categoriesvalidations, categories)
routes.put('/update/:id',verify,updatevalidations,update)
routes.get('/list',list)
routes.get('/activelist',activelist)
routes.delete('/delete/:id',verify,deletevalidations,deleteCat)

module.exports=routes
