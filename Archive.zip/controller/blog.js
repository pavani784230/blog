const Connection = require ('../db')

exports.newblog = async(req,res) => {
    try{
     const {title,description,article, category, status} = req.body
     let query = ' INSERT INTO blog (title, short_description, description, categoryid, status, createdby, createdat) values ($1,$2,$3,$4,$5, $6, NOW())'
     await Connection.query(query, [title, description, article, category, status , req.user.id])
     res.send("blog added successfully")
    }
    catch(e){
     res.status(422).send({status:'error' , message: e.message || e})
    }
}

exports.uploadimage = async(req,res) => {
    try{
     console.log(req)
     res.send(req.file)
    }
    catch(e){
     res.status(422).send({status:'error' , message: e.message || e})
    }
}

exports.updatestatus = async(req,res) => {
    try{
        const {status} = req.body
        let query = `update blog set status = $1 where userid = '${req.user.id}'`
        await Connection.query(query,[status])
        res.send("status updated successfully")
      }
      catch(e){
        res.status(422).send({status:'error' , message: e.message || e})
      }
}

exports.deleteblog = async(req,res) => {
    try{
        await Connection.query(`delete from blog where id = '${req.params.id}'`)
        res.send("blog deleted successfully")
      }
      catch(e){
        res.status(422).send({status:'error' , message: e.message || e})
      }
}

exports.activeblogs = async(req,res) => {
    try{
      let query = ` select title from blog where status = 'active'`
      let {rows} = await Connection.query(query)
      res.send(rows)

    }
    catch(e){
        res.status(422).send({status:'error' , message: e.message || e})
      }
}

exports.list = async(req,res) => {
    try{
        let query = '';
            
        if (req.user.role == 'admin') {
            query = `select title, C.name as category, short_description, description, u.name from blog as b
            left join categories as C on C.id = b.categoryid
            left join users as u on b.createdby = u.id `
        } else {
            query = `select title, C.name as category, short_description, description, u.name from blog as b
            left join categories as C on C.id = b.categoryid
            left join users as u on b.createdby = u.id where b.createdby = ${req.user.id}`
        }
     let {rows} = await Connection.query(query)
     console.log(rows)
     res.send(rows)
    }
    catch(e){
     res.status(422).send({status:'error' , message: e.message || e})
    }
}


exports.allArticles = async(req,res) => {
    try{
        const where = _whereQuery(req.query)
        let query = `select title, C.name as category, short_description, description, u.id as userId, u.name from blog as b
        left join categories as C on C.id = b.categoryid
        left join users as u on b.createdby = u.id  ${where}`
        
        let {rows} = await Connection.query(query)
        res.send(rows)
    }
    catch(e){
     res.status(422).send({status:'error' , message: e.message || e})
    }
}

const _whereQuery = (queryObj)  => {
    let where = `where  b.status = 'active'`

    Object.keys(queryObj).map(e => {
        console.log(e)
        switch (e) {
            case 'category' :
                where += ` AND b.categoryid = ${queryObj.category}`
                break;
            case 'author' :
                where += ` AND b.createdby = ${queryObj.author}`
                break;
            case 'title':
                where += ` AND b.title like  '%${queryObj.author}%'`
                break;
        }

    })

    return where
}