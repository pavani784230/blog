const Post = require('../../models/post')

exports.Post = async(req,res) => {
    try{
      let post = new Post(req.body)
      await post.save()
      res.send("comment added successfully")
    }
    catch(e){
        res.status(422).send({status : "error" , message : e.message || e})
    }
}

exports.list = async(req,res) => {
    try{
       let rows = await Post.find()
       res.send(rows)
    }
    catch(e){
    res.status(422).send({status : "error" , message : e.message || e})
    }
}

exports.deletePost = async(req,res) => {
    try{
    let filter = await Post.findOne({_id: req.params.id})
    if(req.user.id == filter.postedby){
        await Post.remove({_id: req.params.id})
        res.send("comment deleted successfully")
      }
       else{
           res.send("no access")
        }
    }
    catch(e){
        res.status(422).send({status : "error" , message : e.message || e})
    }
}