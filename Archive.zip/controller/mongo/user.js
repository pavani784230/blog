// const Connection = require('../db')
const User = require('../../models/user')
const Blog = require('../../models/blog')
const {secretekey} = require('../../config')
const _ = require('lodash')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt')

exports.signup = async (req,res) => {
    try{
    //  let {user_name,password,role,email,status} = req.body
     req.body.password = await bcrypt.hashSync(req.body.password, 10)
     
    //  let {rows} = await Connection.query("select * from users where user_name = $1",[user_name])
    //  if(rows.length != 0 )throw new Error ("user_name already exist")
    //  let query = ` INSERT INTO users (name,user_name,password,role,email,status,createdat) values ($1,$2,$3,$4,$5,$6, NOW())`
    //  await Connection.query(query,[ _.get(req.body,'name',''),user_name,password,role,email,status || 'active'])
     let user = new User(req.body)
     await user.save();
    res.send("user added successfully")
    }
    catch(e){
        res.status(422).send({status:'error' , message : e.message||e})

    }
}

exports.signin = async (req,res) => {
    try{
     //const{user_name, password} = req.body
     let  rows  = await User.find({user_name : req.body.user_name})
     if ( rows.length == 0 ) throw new Error ("Username is not valid")
     else {
         let match = await bcrypt.compareSync(req.body.password, rows[0].password)
         if ( !match )  throw new Error ("Username / password are not valid")
     }

     let data = {
         id : rows[0]._id,
         name : rows[0].name,
         role : rows[0].role
     }
     const token = await jwt.sign(data,secretekey)
     res.send({status:'success' , token:token})
    }
    catch(e){
        res.status(422).send({status:'error',message: e.message || e})
    }
}

exports.status = async (req,res) => {
    try{
     await User.update({_id: req.user.id},{status:req.body.status})
      res.send("status updated successfully")
    }
    catch(e){ 
        res.status(422).send({status : 'error' , message : e.message || e})
    }
}

exports.updatepassword = async (req,res) => {
    try{
      let rows = await User.find({_id:req.user.id},{password:1})
      if (rows.length == 0) throw new Error ("old password mismatched")
     await User.update({_id:req.user.id},{password:req.body.newpassword})
      res.send("password updated successfully")
    }
    catch(e){ 
        res.status(422).send({status : 'error' , message : e.message || e})
    }
}

exports.getuserinfo  = async (req,res) => {
    try{
       let rows = await User.findById(req.params._id)
       res.status(200).send(rows);
    }
    catch(e){
        res.status(422).send({status:'error',message: e.message || e})
    }
}

exports.userslist =  async (req,res) => {
    try{
     let query = [
         {
             $lookup : {
                from : "blogs",
                localField: "_id",
                foreignField: "createdby",
                as : "count"
             }
         },
     {$project:{
         _id : 1,
         name : 1,
         email : 1,
         status : 1,
         role : 1,
         blogcount:{$size : "$count"}
        }
    }
     ]
     let rows = await User.aggregate(query)
     res.send(rows)
    }
    catch(e){
        res.status(422).send({status:'error',message: e.message || e})
    }
}
