const Blog = require('../../models/blog')
const Post = require('../../models/post')

const mongoose = require('mongoose')
exports.newblog = async(req,res) => {
    try{
     let blog = new Blog(req.body)
     let rows = await blog.save()
     res.send("blog added successfully")
    }
    catch(e){
     res.status(422).send({status:'error' , message: e.message || e})
    }
}

// exports.uploadimage = async(req,res) => {
//     try{
//      console.log(req)
//      res.send(req.file)
//     }
//     catch(e){
//      res.status(422).send({status:'error' , message: e.message || e})
//     }
// }

exports.updatestatus = async(req,res) => {
    try{
        await Blog.update({_id:req.params._id},{status:"req.body.status"})
        res.send("status updated successfully")
      }
      catch(e){
        res.status(422).send({status:'error' , message: e.message || e})
      }
}

exports.deleteblog = async(req,res) => {
    try{
        await Blog.remove({_id:req.params._id})
        res.send("blog deleted successfully")
      }
      catch(e){
        res.status(422).send({status:'error' , message: e.message || e})
      }
}

exports.activeblogs = async(req,res) => {
    try{
      let rows = await Blog.find({status : "active"})
      res.send(rows)

    }
    catch(e){
        res.status(422).send({status:'error' , message: e.message || e})
      }
}

exports.list = async(req,res) => {
    try{
      let rows
      let query =[
        //Step 1
        {
          $lookup : {
            from : "categories",
            localField: "categoryid",
            foreignField: "_id",
            as : "category"
          }
        },
        //Step 2
        {
          $lookup : {
            from : "users",
            localField : "createdby",
            foreignField: "_id",
            as : "postedby"
           }
        },
       {
         $lookup : {
          from : "posts",
          localField : "_id",
          foreignField: "blogid",
          as : "comments"
         }
       },
       {"$limit": parseInt(req.query.limit)}
      ];
      //if(req.user.role != 'admin') query.unshift({$match : {createdby:mongoose.Types.ObjectId(req.user.id)}});
      console.log(query)
      rows = await Blog.aggregate(query);
      // rows = await Blog.find({where}).populate('categoryid').populate('createdby');
      res.send(rows)
    }
    catch(e){
     res.status(422).send({status:'error' , message: e.message || e})
    }
}

exports.allArticles = async(req,res) => {
  try {
    let where = _whereQuery(req.query)
    let rows
    //console.log(where);
    //rows = await Blog.find(where).populate('categoryid').populate('createdby');
    let query = [
      {$match:(where)},
      {
            $lookup : {
              from : "categories",
              localField: "categoryid",
              foreignField: "_id",
              as : "getting"
            }
          },
          //Step 2
          {
            $lookup : {
              from : "users",
              localField : "createdby",
              foreignField: "_id",
              as : "postedby"
             }
          }
    ]
    console.log(query)
    rows = await Blog.aggregate(query);
    console.log(rows)
    res.send(rows)
  }
  catch(e){
    res.status(422).send({status:'error' , message: e.message || e})
  }
}
const _whereQuery = (queryObj)  => {
    let where = {}
    console.log(queryObj)
    Object.keys(queryObj).map(e => {
        switch (e) {
            case 'categoryid' :
                where.categoryid = mongoose.Types.ObjectId(queryObj.categoryid);
                break;
            case 'createdby' :
                where.createdby = mongoose.Types.ObjectId(queryObj.createdby);
                break;
            case 'title':
                where.title = {$regex: queryObj.title, $options: "i"};
                break;
            case 'status' :
               where.status = queryObj.status;
               break;
        }
    })
    return where
}