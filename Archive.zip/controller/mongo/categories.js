//const Connection = require('../db')
const Categories = require('../../models/categories')
const _ = require('lodash')


exports.categories = async(req,res) => {
    try{
        let categories = new Categories(req.body)
         await categories.save()
         res.send("category inserted successfully")
    }
    catch(e) {
        res.status(422).send({status:'error' , message : e.message || e})
    }
}

exports.list= async(req,res) => {
    try{
     let rows  = await Categories.find()
     res.send (rows)
    }
    catch(e){
    res.status({status:'error', message : e.message || e})
    }
}

exports.update = async (req,res) => {
    try{
     await Categories.update({_id: req.params._id},{status:req.body.status})
      res.send("category updated successfully")
    }
    catch(e){ 
        res.status(422).send({status : 'error' , message : e.message || e})
    }
}

exports.deleteCat = async (req,res) => {
    try{
     await Categories.remove({_id: req.params._id})
      res.send("categery deleted successfully")
    }
    catch(e){ 
        res.status(422).send({status : 'error' , message : e.message || e})
    }
}

exports.activelist= async (req,res) => {
    try{
     let rows = await Categories.where('name').where('status').eq('active')
     console.log(rows)
      res.send(rows)
    }
    catch(e){ 
        res.status(422).send({status : 'error' , message : e.message || e})
    }
}

