const Connection = require('../db')
const _ = require('lodash')

exports.categories = async(req,res) => {
    try{
      const {name,status} = req.body
      let query = ` INSERT INTO categories (name,status,createdat) values ($1,$2,NOW())`
      await Connection.query(query,[name,status])
        res.send("category inserted successfully")
    }
    catch(e) {
        res.status(422).send({status:'error' , message : e.message || e})
    }
}

exports.list= async(req,res) => {
    try{
     let { rows } = await Connection.query("select id, name from categories")
     res.send (rows)
    }
    catch(e){
    res.status({status:'error', message : e.message || e})
    }
}

exports.update = async (req,res) => {
    try{
     await Connection.query(` update categories set status = '${req.body.status}' where id = '${req.params.id}'`)
      res.send("categery updated successfully")
    }
    catch(e){ 
        res.status(422).send({status : 'error' , message : e.message || e})
    }
}

exports.deleteCat = async (req,res) => {
    try{
     {
     await Connection.query(` delete from categories  where id = '${req.params.id}'`)
      res.send("categery deleted successfully")
    }
    }
    catch(e){ 
        res.status(422).send({status : 'error' , message : e.message || e})
    }
}

exports.activelist= async (req,res) => {
    try{
     let {rows} = await Connection.query("select id, name from categories where status = 'active'")
     console.log(rows)
      res.send(rows)
    }
    catch(e){ 
        res.status(422).send({status : 'error' , message : e.message || e})
    }
}

