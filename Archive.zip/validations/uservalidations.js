const Joi = require('joi');
const { join } = require('lodash');
const {errorMessage} = require('./customeMessage')
const signupvalidations = (req, res, next) => {
    const schema = Joi.object().keys({
        name: Joi.string(),
        user_name: Joi.string().required().min(5).max(20),
        password: Joi.string().required().min(5).max(10),
        role: Joi.string().valid('user', 'admin').required(),
        email: Joi.string().email().required(),
        status: Joi.string().valid('Active', 'Inactive').required()

    })
    const { error } = schema.validate(req.body);

    if(error) errorMessage(res, 422, error)
    else next();
}

const signinvalidations = (req,res,next) => {
    const schema = Joi.object().keys({
        user_name: Joi.string().required().min(5).max(20),
        password: Joi.string().required().min(5).max(10)
    })
    const {error} = schema.validate(req.body);
    if(error) errorMessage(res, 422, error)
    else next();
    
}

const statusvalidations = (req,res,next) => {
    const schema = Joi.object().keys({
      status: Joi.string().valid('active','inactive').required()  
    })

    const {error} = schema.validate(req.body);
    if(error) errorMessage(res, 422,error)
    else next();
}

const passwordvalidations = (req,res,next) => {
    const schema = Joi.object().keys({
       password : Joi.string().required().min(5).max(10),
       newpassword : Joi.string().required().min(5).max(10)
    })
     const {error} = schema.validate(req.body);
     if (error) errorMessage(res,422, error)
     else next();
}



module.exports = {
    signupvalidations,
    signinvalidations,
    statusvalidations,
    passwordvalidations

}