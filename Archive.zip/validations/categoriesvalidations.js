const  categoriesvalidations = (req,res,next) => {
    let error = false;
    if (req.user.role == 'user') error = "user has no rights"
    if (!error && !req.body.name) error = "name is mandatory"
    if (!error && !req.body.status) error = "please enter status"
    if(error) res.status(403).send({status:'error',message : error.message || error})
    next();
}

const  updatevalidations = (req,res,next) => {
    let error = false;
    if (req.user.role == 'user') error = "user has no rights"
    if (!error && !req.body.status) error = "status is mandatory"
    if (!error && ['active','inactive'].indexOf(req.body.status) <0) error = "status is invalid"
    if(error) res.status(403).send({status:'error',message : error.message || error})
    next();
}

const deletevalidations = (req,res,next) => {
    let error =false;
    if (req.user.role == 'user') error = "user has no rights"
    if(error) res.status(403).send({status:'error',message : error.message || error})
    next();
}

module.exports = {
    categoriesvalidations,
    updatevalidations,
    deletevalidations
}