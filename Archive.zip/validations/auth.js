const jwt = require('jsonwebtoken')
const {secretekey} = require ('../config')
const verify = async(req,res,next) => {
    if (!req.headers && !req.headers['authorization']) {
        res.status(403).send({status:'error' , message : "token required"})
    }

    jwt.verify(req.headers['authorization'],secretekey,(err,userinfo) => {
     if (err || !userinfo) res.status(403).send({status:'error' , message : "token is invalid"})
     req.user = userinfo
     console.log(userinfo)
     next();
    })
}

module.exports = {
    verify
}