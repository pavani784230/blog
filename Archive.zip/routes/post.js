const routes = require ('express').Router()
const {Post,list,deletePost} = require('../controller/mongo/post')
//const {newblogvalidations,updatevalidations} = require('../validations/blogvalidations')
const {verify} = require('../validations/auth')

routes.post('/',verify,Post)
routes.get('/',list)
routes.delete('/:id',verify,deletePost)

module.exports=routes