const routes = require ('express').Router()
const {newblog,categoryid,createdby,updatestatus,deleteblog,activeblogs,list, allArticles, uploadimage} = require('../controller/mongo/blog')
const {newblogvalidations,updatevalidations} = require('../validations/blogvalidations')
const {verify} = require('../validations/auth')
const multer = require('multer')
const upload = multer({ dest: 'uploads/' })

routes.post('/newblog', verify, newblogvalidations, newblog)
routes.put('/update/:_id', verify, updatevalidations, updatestatus)
routes.get('/active', verify, activeblogs)
routes.get('/list', verify, list)
routes.get('/', allArticles)
routes.delete('/:_id', verify, deleteblog)
// routes.post('/uploadimage', upload.single('blog_image'), uploadimage)

module.exports=routes