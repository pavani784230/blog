const routes = require ('express').Router()
const {signup,signin,status,updatepassword,getuserinfo,userslist} = require('../controller/mongo/user')
const {signupvalidations,signinvalidations,statusvalidations,passwordvalidations} = require('../validations/uservalidations')
const {verify} = require('../validations/auth')

routes.post('/signup',signupvalidations,signup)
routes.post('/signin',signinvalidations,signin)
routes.put('/status',verify,statusvalidations,status)
routes.put('/password',verify,passwordvalidations,updatepassword)
routes.get('/userinfo/:_id',getuserinfo)
routes.get('/userslist',userslist)



module.exports=routes