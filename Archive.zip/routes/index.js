const routes = require ('express').Router()
const {verify} = require('../validations/auth')

 routes.use('/user',require('./user'))
 routes.use('/categories',require('./categories'))
 routes.use('/blog',require('./blog'))
 routes.use('/post',require('./post'))

 module.exports = routes