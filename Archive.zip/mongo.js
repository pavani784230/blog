const config = require('./config')
const mongoose = require('mongoose')

mongoose.connect(config.mongo.uri, {
    // useNewUrlParser: true,
    // useCreateIndex: true,
    // useUnifiedTopology: true,
});

mongoose.connection.on("connected", ()=>{
    console.log("MongoDB connection established");
})

mongoose.connection.on("error", (err)=>{
    console.log(`MongoDB connection failed ${err}`);
})

mongoose.connection.on("disconnected", ()=>{
    console.log("MongoDB connection disconnected");
})